"""
ShieldGuard AI 2.0 - Root Test Suite Runner
"""
import os
import sys
import unittest

current_dir = os.path.dirname(os.path.abspath(__file__))
sub_dir = os.path.join(current_dir, "phishing detection system")

if os.path.exists(sub_dir):
    os.chdir(sub_dir)
    sys.path.insert(0, sub_dir)
else:
    sys.path.insert(0, current_dir)

from test_system import TestShieldGuardSystem

if __name__ == "__main__":
    unittest.main()
