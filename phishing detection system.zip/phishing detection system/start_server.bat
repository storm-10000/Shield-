@echo off
TITLE ShieldGuard AI 2.0 - Phishing Detection Platform Server
COLOR 0A
echo ==============================================================================
echo   ShieldGuard AI 2.0 - Spam, Scam and Phishing Threat Detection System
echo ==============================================================================
echo.
echo Starting FastAPI application server...
echo Access Web UI at: http://127.0.0.1:8000
echo Access REST API Docs at: http://127.0.0.1:8000/docs
echo.
python run.py
pause
