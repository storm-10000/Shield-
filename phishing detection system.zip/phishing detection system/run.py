"""
ShieldGuard AI 2.0 - Root Launcher
Launches the FastAPI application server with Uvicorn.
"""
import os
import sys

# Ensure current working directory and subfolder are in path
current_dir = os.path.dirname(os.path.abspath(__file__))
sub_dir = os.path.join(current_dir, "phishing detection system")

if os.path.exists(sub_dir):
    os.chdir(sub_dir)
    sys.path.insert(0, sub_dir)
else:
    sys.path.insert(0, current_dir)

import uvicorn

if __name__ == "__main__":
    print("=" * 70)
    print(" 🛡️ ShieldGuard AI 2.0 Platform Server Starting...")
    print(" Web Interface: http://127.0.0.1:8000")
    print(" Interactive Docs: http://127.0.0.1:8000/docs")
    print("=" * 70)
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
